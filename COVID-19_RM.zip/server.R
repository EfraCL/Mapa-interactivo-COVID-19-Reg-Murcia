library(rgdal)
library(leaflet)
library(htmlwidgets)
library(dplyr)


shinyServer(function(input,output){
  output$mapa<-renderLeaflet({
    {municipios<-readOGR(dsn="municipios.shp",
                        layer="municipios",
                        encoding="ESRI Shapefile")
    municipios<-spTransform(municipios,CRS("+init=epsg:4326"))
    
    n_casos<-readOGR(dsn="casos_municipios.shp",
                     layer="casos_municipios",
                     encoding="ESRI Shapefile")
    n_casos<-spTransform(n_casos,CRS("+init=epsg:4326"))} # Carga de shapefiles
    
    {equivalencia<-read.csv("equivalencias.csv",header=T,sep=";",colClasses = rep("character",2))
    a<-equivalencia[equivalencia$fecha_input==input$fecha,2]
    
    n_casos@data<-select(n_casos@data,ID:POBLACION,contains(as.character(a)))
    names(n_casos@data)[4]<-"num_casos"
    
    minimo<-min(n_casos@data$num_casos[n_casos@data$num_casos>0])
    radio<-(sqrt(n_casos@data$num_casos)/minimo)*3
    
    color<-c()
    color[n_casos@data$num_casos==0]<-"blue"
    color[is.na(color)]<-"red"} # Seleccion de día y definicion de parámetros de puntos: radio y color
    
    read.csv("datos.csv",header=T,sep=";",colClasses = c("character",rep("integer",7)))%>%
      filter(Fecha==a)->temp
    
    temp1<-c("25/03","27/03","30/03","01/04","03/04","06/04","08/04","10/04","13/04","15/04","17/04","20/04","22/04","24/04","27/04","29/04","06/05","13/05")
    
    if(input$fecha%in%temp1[1:10]){
      n_casos@data$num_casos->n
      n[n==0]<-"<5"
      n2<-round(n_casos@data$num_casos*100/temp$Total2,2)
      n2[n2==0]<-""
      n3<-round(n_casos@data$num_casos*100/n_casos@data$POBLACION,2)
      n3[n3==0]<-""

      n_casos.popup<-paste("<h3 style='text-align:center;'>Información</h3>",
                         "<b>Municipio:</b>",n_casos@data$MUNICIPIO,"<br/>","<br/>",
                      "<table class='table'><tr>
                          <td id='izq'>Nº de casos detectados</td>
                          <td id='negrita'>",n,"</td>
                         </tr>
                         <tr>
                          <td id='izq'>Proporción respecto al total de infectados detectados (%)</td>
                          <td id='negrita'>",n2,"</td>
                         </tr>
                         <tr>
                          <td id='izq'>Proporción de población del municipio infectada detectada (%) </td>
                          <td id='negrita'>",n3,"</td>
                        </tr>
                      </table>")
      rm(n,n2,n3)
      
    } else if(!input$fecha%in%temp1){
      n_casos.popup<-paste("<h3 style='text-align:center;'>Información</h3>",
                           "<b>Municipio:</b>",n_casos@data$MUNICIPIO,"<br/>","<br/>",
                           "<table class='table'><tr>
                          <td id='izq'>Nº de casos detectados</td>
                          <td id='negrita'>",n_casos@data$num_casos,"</td>
                         </tr>
                         <tr>
                          <td id='izq'>Proporción respecto al total de infectados detectados (%)</td>
                          <td id='negrita'>",round(n_casos@data$num_casos*100/temp$Total2,2),"</td>
                         </tr>
                         <tr>
                          <td id='izq'>Proporción de población del municipio infectada detectada (%) </td>
                          <td id='negrita'>",round(n_casos@data$num_casos*100/n_casos@data$POBLACION,2),"</td>
                        </tr>
                      </table>")
    } else{
      n_casos@data$num_casos->n
      n[n==0]<-"<5"
      n2<-round(n_casos@data$num_casos*100/temp$Total2,2)
      n2[n2==0]<-""
      n3<-round(n_casos@data$num_casos*100/n_casos@data$POBLACION,2)
      n3[n3==0]<-""
      
      read.csv("recuperados.csv",header=T,sep=";",stringsAsFactors = F)%>%
        select(a)->recup
      names(recup)[1]<-"num_recup"
      
      n4<-recup$num_recup
      n4[n4==0]<-"<5"
      
      n5<-round(recup$num_recup*100/n_casos@data$num_casos,2)
      n5[n5==0|is.na(n5)]<-""
      
      n_casos.popup<-paste("<h4 style='text-align:center;'>Información</h4>","<br/>",
                                                    "<b>Municipio:</b>",n_casos@data$MUNICIPIO,"<br/>","<br/>",
                                                    "<table class='table'><tr>
                                                    <td id='izq'>Nº de casos detectados</td>
                                                    <td id='negrita'>",n,"</td>
                                                    </tr>
                                                    <tr>
                                                    <td id='izq'>Proporción respecto al total de infectados detectados (%)</td>
                                                    <td id='negrita'>",n2,"</td>
                                                    </tr>
                                                    <tr>
                                                    <td id='izq'>Proporción de población del municipio infectada detectada (%) </td>
                                                    <td id='negrita'>",n3,"</td>
                                                    </tr>
                                                    <tr>
                                                    <td id='izq'>Nº de altas epidemiológicas</td>
                                                    <td id='negrita'>",n4,"</td>
                                                    </tr>
                                                    <tr>
                                                    <td id='izq'>Proporción de altas respecto al número de infectados detectados (%)</td>
                                                    <td id='negrita'>",n5,"</td>
                                                    </tr>
                                                    </table>")
      rm(n,n2,n3,n4,n5)
      }

    if(input$fecha%in%temp1){
    leaflet()%>%
      addPolygons(data=municipios,fillColor = "green",
                  color = "black",opacity = 0.7, group="Municipios")%>%
      addCircleMarkers(data=n_casos, popup= n_casos.popup,
                       radius=radio, color=color,opacity = 1,fillOpacity = 1)%>%
      addTiles(group="Open Street Map")%>%
      addLayersControl(overlayGroups = c("Municipios"),
                       options = layersControlOptions(collapsed = TRUE)) %>%
      addLegend("bottomleft", colors = c("blue","red")
                ,labels=c("Menos de 5 casos","Más de 5 casos"), title = "Leyenda")
      } else{
      minimo<-min(n_casos@data$num_casos[n_casos@data$num_casos>0])
      radio<-(sqrt(n_casos@data$num_casos)/minimo)*0.6
      
      leaflet()%>%
        addPolygons(data=municipios,fillColor = "green",
                    color = "black",opacity = 0.7, group="Municipios")%>%
        addCircleMarkers(data=n_casos, popup= n_casos.popup,
                         radius=radio, color=color,opacity = 1,fillOpacity = 1)%>%
        addTiles(group="Open Street Map")%>%
        addLayersControl(overlayGroups = c("Municipios"),
                         options = layersControlOptions(collapsed = TRUE)) %>%
        addLegend("bottomleft", colors = c("blue","red")
                  ,labels=c("Sin casos detectados","Con casos detectados"), title = "Leyenda")
      
    }
      
      })
  

  output$tabla<-renderTable({
    equivalencia<-read.csv("equivalencias.csv",header=T,sep=";",colClasses = rep("character",2))
    
    a<-equivalencia[equivalencia$fecha_input==input$fecha,2]
    b<-equivalencia[which(equivalencia$fecha_input==input$fecha)-1,2]
    
    read.csv("datos.csv",header=T,sep=";",colClasses = c("character",rep("integer",7)))->temp
    
    if(input$fecha!="25/03"){
    
    filter(temp,Fecha==a)%>%
      select(-Fecha)->temp1
    n<-as.numeric(temp1[1,])

    filter(temp,Fecha==b)%>%
      select(-Fecha)->temp2
    m<-as.numeric(temp2[1,])
    
    p<-round((n-m)*100/m,2)
    p[c(2,3,4,7)]<-""
  
    temp1<-as.data.frame(t(temp1))
    temp1$variacion<-p

    rm(a,b,temp)
    names(temp1)<-c("Total","Variación (%)")
    rownames(temp1)<-c("Infectados detectados en la Región hasta la fecha","Infectados detectados en la Región con información detallada hasta la fecha","Infectados detectados en municipios con menos de cinco casos hasta la fecha","Infectados de la Región en otras Comunidades Autónomas hasta la fecha",
                      "Fallecidos hasta la fecha","Recuperados (alta epidemiológica) hasta la fecha","Personas infectadas confirmadas hasta la fecha (descontando recuperados y fallecidos)")
    temp1
    }
    else{
      filter(temp,Fecha==a)%>%
        select(-Fecha)->temp1
      
      temp1<-as.data.frame(t(temp1))
      
      names(temp1)<-c("Total")
      rownames(temp1)<-c("Infectados detectados en la Región hasta la fecha","Infectados detectados en la Región con información detallada hasta la fecha","Infectados detectados en municipios con menos de cinco casos hasta la fecha","Infectados de la Región en otras Comunidades Autónomas hasta la fecha",
                         "Fallecidos hasta la fecha","Recuperados (alta epidemiológica) hasta la fecha","Personas infectadas confirmadas hasta la fecha (descontando recuperados y fallecidos)")
      temp1
    }
    
  },rownames = T,striped = T,align = "c")
  })




